
package com.example.profileappbaru;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {

    private final int bg = Color.rgb(248, 246, 241);
    private final int purple = Color.rgb(91, 75, 101);
    private final int ink = Color.rgb(48, 45, 52);

    private LinearLayout content;
    private EditText inputName, inputUsername, inputBio, inputEmail;
    private boolean editing = false;

    private int dp(float value) {
        return (int) (value *
                getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private String saved(String key, String fallback) {
        return getPreferences(MODE_PRIVATE)
                .getString(key, fallback);
    }

    private TextView text(String value, int size,
                          int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);

        if (bold) {
            t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        }

        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private Button button(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(14);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackground(shape(purple, 10));
        return b;
    }

    private void gap(int height) {
        View v = new View(this);
        content.addView(v,
                new LinearLayout.LayoutParams(1, dp(height)));
    }

    private void setupPage() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);

        content = column();
        content.setPadding(dp(20), dp(18), dp(20), dp(24));
        content.setBackgroundColor(bg);

        scroll.addView(content);
        setContentView(scroll);
    }

    private void center(TextView t) {
        t.setGravity(Gravity.CENTER);
    }

    // FOTO PROFIL DARI DRAWABLE
    private ImageView addAvatar() {
        ImageView avatar = new ImageView(this);

        avatar.setImageResource(R.drawable.profile_photo);
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        avatar.setBackground(shape(
                Color.rgb(174, 164, 182), 100));
        avatar.setClipToOutline(true);
        avatar.setContentDescription("Foto profil");

        LinearLayout.LayoutParams p =
                new LinearLayout.LayoutParams(dp(100), dp(100));

        p.gravity = Gravity.CENTER;
        p.topMargin = dp(18);
        p.bottomMargin = dp(14);

        content.addView(avatar, p);
        return avatar;
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        tampilProfil();
    }

    // HALAMAN PROFIL
    private void tampilProfil() {
        editing = false;
        setupPage();

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = text("Profile", 23, ink, true);
        header.addView(title,
                new LinearLayout.LayoutParams(0, -2, 1));

        Button edit = button("Edit Profile");
        header.addView(edit,
                new LinearLayout.LayoutParams(-2, dp(46)));

        content.addView(header);

        edit.setOnClickListener(v -> tampilEdit());

        TextView banner = text("MY PROFILE", 19, Color.WHITE, true);
        banner.setGravity(Gravity.CENTER);
        banner.setBackground(shape(
                Color.rgb(178, 168, 185), 14));

        LinearLayout.LayoutParams bannerParams =
                new LinearLayout.LayoutParams(-1, dp(135));
        bannerParams.topMargin = dp(20);

        content.addView(banner, bannerParams);

        // Menampilkan foto profil
        addAvatar();

        TextView name = text(
                saved("name", "Devon Lane"), 22, ink, true);
        center(name);
        content.addView(name);

        String username = saved("username", "devonlane");
        if (!username.startsWith("@")) {
            username = "@" + username;
        }

        TextView user = text(username, 14, Color.GRAY, false);
        center(user);
        content.addView(user);

        gap(12);

        TextView description = text(
                saved("bio",
                        "Photographer | Travel lover | Sharing moments"),
                14, ink, false);
        center(description);
        content.addView(description);

        gap(18);

        Button follow = button("Follow");

        LinearLayout.LayoutParams followParams =
                new LinearLayout.LayoutParams(dp(155), dp(46));
        followParams.gravity = Gravity.CENTER;

        content.addView(follow, followParams);

        follow.setOnClickListener(v ->
                Toast.makeText(this,
                        "Berhasil mengikuti profil",
                        Toast.LENGTH_SHORT).show());

        gap(24);

        LinearLayout stats = new LinearLayout(this);
        stats.setGravity(Gravity.CENTER);

        String[] numbers = {"205", "205K", "870"};
        String[] labels = {"Posts", "Followers", "Following"};

        for (int i = 0; i < numbers.length; i++) {
            LinearLayout item = column();
            item.setGravity(Gravity.CENTER);

            TextView number = text(numbers[i], 19, ink, true);
            TextView label = text(labels[i], 12, Color.GRAY, false);

            center(number);
            center(label);

            item.addView(number);
            item.addView(label);

            stats.addView(item,
                    new LinearLayout.LayoutParams(0, -2, 1));
        }

        content.addView(stats);
        gap(25);

        content.addView(text("Photos", 18, ink, true));
        gap(10);

        // GALERI FOTO DARI DRAWABLE
        int[] photos = {
                R.drawable.photo1,
                R.drawable.photo2,
                R.drawable.photo3,
                R.drawable.photo4,
                R.drawable.photo5,
                R.drawable.profile_photo
        };

        for (int row = 0; row < 2; row++) {
            LinearLayout photoRow = new LinearLayout(this);
            photoRow.setOrientation(LinearLayout.HORIZONTAL);

            for (int col = 0; col < 3; col++) {
                int index = row * 3 + col;

                ImageView photo = new ImageView(this);
                photo.setImageResource(photos[index]);
                photo.setScaleType(
                        ImageView.ScaleType.CENTER_CROP);
                photo.setBackground(shape(Color.WHITE, 7));
                photo.setClipToOutline(true);
                photo.setContentDescription(
                        "Foto galeri " + (index + 1));

                LinearLayout.LayoutParams p =
                        new LinearLayout.LayoutParams(
                                0, dp(105), 1);

                p.setMargins(dp(3), dp(3), dp(3), dp(3));

                photoRow.addView(photo, p);
            }

            content.addView(photoRow);
        }
    }

    // LABEL FORM EDIT
    private void addLabel(String label) {
        TextView t = text(label, 14, ink, true);

        LinearLayout.LayoutParams p =
                new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(6);

        content.addView(t, p);
    }

    // INPUT FORM EDIT
    private EditText addField(String hint, String value, int lines) {
        EditText e = new EditText(this);

        e.setText(value);
        e.setHint(hint);
        e.setTextSize(14);
        e.setTextColor(ink);
        e.setPadding(dp(12), dp(8), dp(12), dp(8));
        e.setBackground(shape(Color.WHITE, 9));

        if (lines == 1) {
            e.setSingleLine(true);
        } else {
            e.setMinLines(lines);
            e.setGravity(Gravity.TOP | Gravity.START);
        }

        LinearLayout.LayoutParams p =
                new LinearLayout.LayoutParams(
                        -1, dp(lines == 1 ? 48 : 82));

        p.bottomMargin = dp(14);

        content.addView(e, p);
        return e;
    }

    // HALAMAN EDIT PROFIL
    private void tampilEdit() {
        editing = true;
        setupPage();

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);

        Button back = button("< Back");
        header.addView(back);
        back.setOnClickListener(v -> tampilProfil());

        TextView title = text("Edit Profile", 21, ink, true);
        title.setGravity(Gravity.CENTER);

        header.addView(title,
                new LinearLayout.LayoutParams(0, dp(48), 1));

        content.addView(header);

        // Foto profil juga tampil pada halaman edit
        addAvatar();

        addLabel("Name");
        inputName = addField("Enter name",
                saved("name", "Devon Lane"), 1);

        addLabel("Username");
        inputUsername = addField("Enter username",
                saved("username", "devonlane"), 1);

        addLabel("Bio");
        inputBio = addField("Write your bio",
                saved("bio",
                        "Photographer, travel lover, content creator."),
                3);

        addLabel("Contact");
        inputEmail = addField("Email address",
                saved("email", "devonlane@email.com"), 1);

        addLabel("Category");

        TextView category = text(
                "Creator / Blogger", 14, ink, false);
        category.setGravity(Gravity.CENTER_VERTICAL);
        category.setPadding(dp(12), 0, dp(12), 0);
        category.setBackground(shape(Color.WHITE, 9));

        content.addView(category,
                new LinearLayout.LayoutParams(-1, dp(48)));

        gap(20);

        Button save = button("Save Changes");
        content.addView(save,
                new LinearLayout.LayoutParams(-1, dp(50)));

        save.setOnClickListener(v -> {
            String name = inputName.getText().toString().trim();
            String user = inputUsername.getText()
                    .toString().trim();

            if (name.isEmpty() || user.isEmpty()) {
                Toast.makeText(this,
                        "Nama dan username harus diisi",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            getPreferences(MODE_PRIVATE).edit()
                    .putString("name", name)
                    .putString("username", user)
                    .putString("bio",
                            inputBio.getText().toString().trim())
                    .putString("email",
                            inputEmail.getText().toString().trim())
                    .apply();

            Toast.makeText(this,
                    "Profil berhasil disimpan",
                    Toast.LENGTH_SHORT).show();

            tampilProfil();
        });
    }

    @Override
    public void onBackPressed() {
        if (editing) {
            tampilProfil();
        } else {
            super.onBackPressed();
        }
    }
}
